import numpy as np
from .bearing import char_freqs, impact_freq
MODEL_VERSION = 'envelope-impact-model v0.1'

def simulated_envelope(f, fr, geom, fault, n_harm=5, n_side=2, decay=0.35, mod_depth=0.6, width_hz=0.3):
    cf = char_freqs(fr, **geom)
    fi = impact_freq(fault, cf)
    fm = {'outer_race': None, 'inner_race': fr, 'rolling_element': cf['FTF']}[fault]
    E = np.zeros_like(f)

    def line(f0, a):
        nonlocal E
        E += a * np.exp(-0.5 * ((f - f0) / width_hz) ** 2)
    for k in range(1, n_harm + 1):
        a = np.exp(-decay * (k - 1))
        line(k * fi, a)
        if fm:
            for m in range(1, n_side + 1):
                line(k * fi + m * fm, a * mod_depth / m)
                line(k * fi - m * fm, a * mod_depth / m)
    if fm:
        line(fm, 0.5)
    return E

def similarity(Em, Es, mask):
    a = Em[mask] - Em[mask].mean()
    b = Es[mask] - Es[mask].mean()
    return float(np.sum(a * b) / np.sqrt(np.sum(a ** 2) * np.sum(b ** 2)))
