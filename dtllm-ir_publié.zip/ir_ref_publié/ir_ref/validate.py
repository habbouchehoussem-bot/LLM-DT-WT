import json, os
from jsonschema import Draft202012Validator
from .facts import char_freq_rule, indicator_rule, dt_match_rule
SCHEMA = json.load(open(os.path.join(os.path.dirname(__file__), '..', 'schema', 'record.schema.json')))

def schema_errors(rec):
    return [e.message for e in Draft202012Validator(SCHEMA).iter_errors(rec)]

def semantic_errors(rec):
    errs = []
    ids = [f['id'] for f in rec['facts']]
    if len(ids) != len(set(ids)):
        errs.append('duplicate fact identifiers')
    if not set(rec['basis']) <= set(ids):
        errs.append('basis refers to unknown facts')
    if 'control action' not in rec['forbidden']:
        errs.append('control action must be forbidden')
    if any((f['type'] == 'dt_match' for f in rec['facts'])) and (not rec['versions'].get('dt')):
        errs.append('DT-derived facts without DT version')
    return errs

def recompute_errors(rec, tol=1e-09):
    errs = []
    for f in rec['facts']:
        p, x = (f['rule']['params'], f['inputs'])
        if f['type'] == 'char_freq':
            r = char_freq_rule(x['f_pk_hz'], x['A_pk'], x['noise_floor'], f['ref'], p['delta_f_hz'], p['eps_s'], p['snr_min'])
            if abs(r['tol_hz'] - f['tol_hz']) > tol or r['holds'] != f['holds']:
                errs.append(f'{f['id']}: not reproducible')
        elif f['type'] == 'indicator':
            r = indicator_rule(x['x'], x['mu_base'], x['sigma_base'], p['lambda'], x['u_x'])
            if r['holds'] != f['holds']:
                errs.append(f'{f['id']}: not reproducible')
        elif f['type'] == 'dt_match':
            h = dt_match_rule(x['similarity'], x['amplitude_ratio'], p['s_min'], p['rho_min'], p['use_amplitude'])
            if h != f['holds']:
                errs.append(f'{f['id']}: not reproducible')
    return errs

def domain_flags(rec):
    flags = []
    for k, (lo, hi) in rec['validity'].items():
        v = rec['regime'].get(k)
        if v is None or not lo <= v <= hi:
            flags.append(f'out_of_domain:{k}')
    return flags

def validate(rec):
    errs = schema_errors(rec)
    if not errs:
        errs += semantic_errors(rec) + recompute_errors(rec)
    return {'valid': not errs, 'errors': errs, 'flags': domain_flags(rec) if not errs else []}
