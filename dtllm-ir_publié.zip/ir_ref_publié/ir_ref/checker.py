import re
FAULT_TERMS = {'outer_race': ['outer-race', 'outer race', 'bpfo'], 'inner_race': ['inner-race', 'inner race', 'bpfi'], 'rolling_element': ['rolling element', 'rolling-element', 'ball', 'bsf']}
NEGATION = re.compile('\\b(no|not|without|absent|within baseline|none)\\b', re.I)
CERTAINTY = re.compile('\\b(confirmed|certainly|definitely|is a|has a|proves?)\\b', re.I)
HEDGE = re.compile('\\b(consistent with|hypothes\\w*|may|might|suggests?|likely|possible)\\b', re.I)

def faults_in(text):
    t = text.lower()
    return {k for k, ws in FAULT_TERMS.items() if any((w in t for w in ws))}

def numbers_in(text):
    t = re.sub('\\[F\\d+\\]', '', text)
    return [float(x) for x in re.findall('(?<![\\w.])(\\d+(?:\\.\\d+)?)', t)]

def fact_numbers(f):
    vals = [f['value'], f['ref']] + [v for v in f['inputs'].values() if isinstance(v, (int, float))]
    for k in ('tol_hz', 'unc_hz', 'tol', 'unc', 'snr', 'threshold'):
        if k in f:
            vals.append(f[k])
    return vals

def check(explanation, record, rel_tol=0.02):
    facts = {f['id']: f for f in record['facts']}
    report = []
    for s in [x.strip() for x in re.split('(?<=[.!?])\\s+', explanation) if x.strip()]:
        ids = re.findall('\\[(F\\d+)\\]', s)
        issues = []
        unknown = [i for i in ids if i not in facts]
        if unknown:
            issues.append('unknown_id')
        cited = [facts[i] for i in ids if i in facts]
        if not ids and faults_in(s):
            issues.append('uncited_conclusion')
        if cited:
            pool = [v for f in cited for v in fact_numbers(f)]
            for v in numbers_in(s):
                if v in (1, 2, 3) and re.search(f'\\b{int(v)}x', s):
                    continue
                if not any((abs(v - p) <= rel_tol * max(abs(p), 1e-09) + 0.05 for p in pool)):
                    issues.append('value_mismatch')
                    break
            negated = bool(NEGATION.search(s))
            if any((f['holds'] == negated for f in cited)):
                issues.append('polarity_contradiction')
            if any((f['type'] == 'dt_match' for f in cited)) and CERTAINTY.search(s) and (not HEDGE.search(s)):
                issues.append('hypothesis_as_certainty')
            claimed = faults_in(s)
            evid = {f.get('fault') for f in cited if f.get('fault')}
            if claimed and evid and (not claimed <= evid):
                issues.append('fault_inconsistent_with_evidence')
        report.append({'sentence': s, 'ids': ids, 'issues': sorted(set(issues))})
    return report
