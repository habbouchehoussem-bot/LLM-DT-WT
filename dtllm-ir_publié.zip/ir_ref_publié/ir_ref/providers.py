import numpy as np
from abc import ABC, abstractmethod
from .signal import envelope_spectrum

class SignatureProvider(ABC):
    name = 'unnamed'
    version = '0'
    model_class = 'unspecified'
    calibration = 'not calibrated'
    maturity = 'digital model'

    @abstractmethod
    def envelope(self, f, fr, geom, fault):
        pass

    def metadata(self):
        return {'dt': f'{self.name} {self.version}', 'dt_model_class': self.model_class, 'calib': self.calibration, 'dt_maturity': self.maturity}

class ReferenceImpactModel(SignatureProvider):
    name = 'reference-impact-model'
    version = '0.1'
    model_class = 'physics-based, linear (impact train with amplitude modulation)'
    calibration = 'not calibrated (unit amplitudes)'
    maturity = 'digital model'

    def envelope(self, f, fr, geom, fault):
        from .dt_model import simulated_envelope
        return simulated_envelope(f, fr, geom, fault)

class FileDTProvider(SignatureProvider):

    def __init__(self, files, band, name, version, model_class, calibration, maturity):
        self.files, self.band = (files, band)
        self.name, self.version, self.model_class = (name, version, model_class)
        self.calibration, self.maturity = (calibration, maturity)
        self._cache = {}

    def envelope(self, f, fr, geom, fault):
        if fault not in self._cache:
            d = np.load(self.files[fault])
            fs_sim, E_sim = envelope_spectrum(d['x'], float(d['fs']), self.band)
            self._cache[fault] = (fs_sim, E_sim, float(d['fr']))
        fs_sim, E_sim, fr_sim = self._cache[fault]
        return np.interp(f, fs_sim * fr / fr_sim, E_sim, left=0.0, right=0.0)
