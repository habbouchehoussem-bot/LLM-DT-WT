import numpy as np
from .bearing import char_freqs, impact_freq
from .dt_model import similarity

def char_freq_rule(f_pk, A_pk, noise, fc_h, delta_f, eps_s, snr_min):
    tau = max(2 * delta_f, eps_s * fc_h)
    u = delta_f / 2
    dev = abs(f_pk - fc_h)
    holds = bool(dev <= tau and A_pk / noise >= snr_min)
    margin = tau - dev
    return {'tol_hz': tau, 'unc_hz': u, 'dev_hz': dev, 'margin_hz': margin, 'snr': A_pk / noise, 'holds': holds, 'borderline': bool(abs(margin) < u)}

def char_freq_fact(fid, f, E, fr, geom, fault, h, delta_f, eps_s=0.02, snr_min=3.0, search=1.5):
    cf = char_freqs(fr, **geom)
    fc_h = h * impact_freq(fault, cf)
    tau = max(2 * delta_f, eps_s * fc_h)
    win = (f >= fc_h - search * tau) & (f <= fc_h + search * tau)
    i = np.argmax(np.where(win, E, -np.inf))
    f_pk, A_pk = (float(f[i]), float(E[i]))
    loc = (f >= fc_h - 10 * tau) & (f <= fc_h + 10 * tau) & ~win
    noise = float(np.median(E[loc]))
    r = char_freq_rule(f_pk, A_pk, noise, fc_h, delta_f, eps_s, snr_min)
    key = {'outer_race': 'BPFO', 'inner_race': 'BPFI', 'rolling_element': '2xBSF'}[fault]
    return {'id': fid, 'type': 'char_freq', 'stmt': f'envelope peak at {h}x{key}' if r['holds'] else f'no envelope peak at {h}x{key}', 'fault': fault, 'inputs': {'f_pk_hz': f_pk, 'A_pk': A_pk, 'noise_floor': noise, 'fr_hz': fr, 'geometry': geom}, 'rule': {'name': 'char_freq', 'params': {'h': h, 'delta_f_hz': delta_f, 'eps_s': eps_s, 'snr_min': snr_min, 'search': search}}, 'value': f_pk, 'unit': 'Hz', 'ref': fc_h, **r}

def indicator_rule(x, mu, sigma, lam, u_x):
    thr = mu + lam * sigma
    return {'threshold': thr, 'holds': bool(x >= thr), 'borderline': bool(abs(x - thr) < u_x)}

def indicator_fact(fid, name, x, u_x, mu, sigma, n_base, lam=3.0):
    r = indicator_rule(x, mu, sigma, lam, u_x)
    return {'id': fid, 'type': 'indicator', 'stmt': f'{name} above baseline' if r['holds'] else f'{name} within baseline', 'inputs': {'x': x, 'u_x': u_x, 'mu_base': mu, 'sigma_base': sigma, 'n_base': n_base}, 'rule': {'name': 'indicator', 'params': {'lambda': lam, 'indicator': name}}, 'value': x, 'unit': '-', 'ref': mu, 'tol': lam * sigma, 'unc': u_x, **r}

def harmonic_amplitude(f, E, fc, n_harm, tau):
    vals = []
    for k in range(1, n_harm + 1):
        w = (f >= k * fc - tau) & (f <= k * fc + tau)
        vals.append(E[w].max())
    return float(np.mean(vals))

def dt_match_rule(s, rho, s_min, rho_min, use_amplitude=True):
    return bool(s >= s_min and (rho >= rho_min if use_amplitude else True))

def dt_match_facts(start_id, f, E_m, E_base, fr, geom, band, provider, s_min=0.3, rho_min=3.0, delta=0.1, n_harm=3, eps_s=0.02, delta_f=0.1, use_amplitude=True):
    mask = (f >= band[0]) & (f <= band[1])
    out = []
    for j, fault in enumerate(['outer_race', 'inner_race', 'rolling_element']):
        E_s = provider.envelope(f, fr, geom, fault)
        s = similarity(E_m, E_s, mask)
        fc = impact_freq(fault, char_freqs(fr, **geom))
        tau = max(2 * delta_f, eps_s * fc)
        rho = harmonic_amplitude(f, E_m, fc, n_harm, tau) / harmonic_amplitude(f, E_base, fc, n_harm, tau)
        holds = dt_match_rule(s, rho, s_min, rho_min, use_amplitude)
        out.append({'id': f'F{start_id + j}', 'type': 'dt_match', 'fault': fault, 'stmt': f'DT hypothesis: {fault.replace('_', ' ')} defect' if holds else f'DT: {fault.replace('_', ' ')} signature not matched', 'inputs': {'similarity': s, 'amplitude_ratio': rho, 'fr_hz': fr}, 'rule': {'name': 'dt_match', 'params': {'band_hz': list(band), 's_min': s_min, 'rho_min': rho_min, 'n_harm': n_harm, 'use_amplitude': use_amplitude, 'dt_model': f'{provider.name} {provider.version}'}}, 'value': s, 'unit': '-', 'ref': s_min, 'holds': holds})
    held = sorted([o for o in out if o['holds']], key=lambda o: -o['inputs']['similarity'])
    ranking = {'candidates': [o['fault'] for o in held], 'delta': delta, 'margin': held[0]['inputs']['similarity'] - held[1]['inputs']['similarity'] if len(held) > 1 else None}
    ranking['ambiguous'] = bool(ranking['margin'] is not None and ranking['margin'] < delta)
    return (out, ranking)
