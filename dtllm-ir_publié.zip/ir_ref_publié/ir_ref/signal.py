import numpy as np
from scipy.signal import butter, sosfiltfilt, hilbert

def envelope_spectrum(x, fs, band):
    sos = butter(4, [band[0] / (fs / 2), band[1] / (fs / 2)], btype='band', output='sos')
    xb = sosfiltfilt(sos, x - np.mean(x))
    env = np.abs(hilbert(xb)) ** 2
    env = env - env.mean()
    N = len(env)
    w = np.hanning(N)
    E = 2 * np.abs(np.fft.rfft(env * w)) / w.sum()
    f = np.fft.rfftfreq(N, 1 / fs)
    return (f, E)

def kurtosis(x):
    x = np.asarray(x, float) - np.mean(x)
    return float(np.mean(x ** 4) / np.mean(x ** 2) ** 2)

def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean((x - x.mean()) ** 2)))

def segment_stats(x, fs, seg_s, func):
    L = int(seg_s * fs)
    vals = [func(x[i:i + L]) for i in range(0, len(x) - L + 1, L)]
    return (float(np.mean(vals)), float(np.std(vals, ddof=1)), len(vals))
