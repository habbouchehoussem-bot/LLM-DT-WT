import math

def char_freqs(fr, n, d, D, alpha_deg=0.0):
    c = d / D * math.cos(math.radians(alpha_deg))
    return {'FTF': fr / 2 * (1 - c), 'BPFO': n * fr / 2 * (1 - c), 'BPFI': n * fr / 2 * (1 + c), 'BSF': D * fr / (2 * d) * (1 - c ** 2)}
FAULT_SIGNATURE = {'outer_race': ('BPFO', None), 'inner_race': ('BPFI', 'fr'), 'rolling_element': ('2BSF', 'FTF')}

def impact_freq(fault, cf):
    key, _ = FAULT_SIGNATURE[fault]
    return 2 * cf['BSF'] if key == '2BSF' else cf[key]
