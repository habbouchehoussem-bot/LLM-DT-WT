import os, sys, urllib.request, urllib.parse
MIRROR = 'https://raw.githubusercontent.com/s-whynot/CWRU-dataset/main/'
REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
DEST = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(REPO, 'cwru')
FILES = ['12k_Drive_End_Bearing_Fault_Data/B/007/118_0.mat', '12k_Drive_End_Bearing_Fault_Data/B/007/119_1.mat', '12k_Drive_End_Bearing_Fault_Data/B/007/120_2.mat', '12k_Drive_End_Bearing_Fault_Data/B/007/121_3.mat', '12k_Drive_End_Bearing_Fault_Data/B/014/185_0.mat', '12k_Drive_End_Bearing_Fault_Data/B/014/186_1.mat', '12k_Drive_End_Bearing_Fault_Data/B/014/187_2.mat', '12k_Drive_End_Bearing_Fault_Data/B/014/188_3.mat', '12k_Drive_End_Bearing_Fault_Data/B/021/222_0.mat', '12k_Drive_End_Bearing_Fault_Data/B/021/223_1.mat', '12k_Drive_End_Bearing_Fault_Data/B/021/224_2.mat', '12k_Drive_End_Bearing_Fault_Data/B/021/225_3.mat', '12k_Drive_End_Bearing_Fault_Data/IR/007/105_0.mat', '12k_Drive_End_Bearing_Fault_Data/IR/007/106_1.mat', '12k_Drive_End_Bearing_Fault_Data/IR/007/107_2.mat', '12k_Drive_End_Bearing_Fault_Data/IR/007/108_3.mat', '12k_Drive_End_Bearing_Fault_Data/IR/014/169_0.mat', '12k_Drive_End_Bearing_Fault_Data/IR/014/170_1.mat', '12k_Drive_End_Bearing_Fault_Data/IR/014/171_2.mat', '12k_Drive_End_Bearing_Fault_Data/IR/014/172_3.mat', '12k_Drive_End_Bearing_Fault_Data/IR/021/209_0.mat', '12k_Drive_End_Bearing_Fault_Data/IR/021/210_1.mat', '12k_Drive_End_Bearing_Fault_Data/IR/021/211_2.mat', '12k_Drive_End_Bearing_Fault_Data/IR/021/212_3.mat', '12k_Drive_End_Bearing_Fault_Data/OR/007/@6/130@6_0.mat', '12k_Drive_End_Bearing_Fault_Data/OR/007/@6/131@6_1.mat', '12k_Drive_End_Bearing_Fault_Data/OR/007/@6/132@6_2.mat', '12k_Drive_End_Bearing_Fault_Data/OR/007/@6/133@6_3.mat', '12k_Drive_End_Bearing_Fault_Data/OR/014/197@6_0.mat', '12k_Drive_End_Bearing_Fault_Data/OR/014/198@6_1.mat', '12k_Drive_End_Bearing_Fault_Data/OR/014/199@6_2.mat', '12k_Drive_End_Bearing_Fault_Data/OR/014/200@6_3.mat', '12k_Drive_End_Bearing_Fault_Data/OR/021/@6/234_0.mat', '12k_Drive_End_Bearing_Fault_Data/OR/021/@6/235_1.mat', '12k_Drive_End_Bearing_Fault_Data/OR/021/@6/236_2.mat', '12k_Drive_End_Bearing_Fault_Data/OR/021/@6/237_3.mat', 'Normal/100_Normal_3.mat', 'Normal/97_Normal_0.mat', 'Normal/98_Normal_1.mat', 'Normal/99_Normal_2.mat']

def main():
    for i, rel in enumerate(FILES, 1):
        out = os.path.join(DEST, *rel.split('/'))
        if os.path.exists(out) and os.path.getsize(out) > 0:
            print(f'[{i:2d}/{len(FILES)}] already present: {rel}')
            continue
        os.makedirs(os.path.dirname(out), exist_ok=True)
        url = MIRROR + urllib.parse.quote(rel)
        print(f'[{i:2d}/{len(FILES)}] downloading {rel}')
        tmp = out + '.part'
        urllib.request.urlretrieve(url, tmp)
        os.replace(tmp, out)
    print('Done. Data folder:', DEST)
if __name__ == '__main__':
    main()
