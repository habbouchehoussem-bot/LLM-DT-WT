import glob, json, os, re, sys, random
import numpy as np, scipy.io as sio
from scipy.signal import resample_poly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from ir_ref.signal import envelope_spectrum, kurtosis, segment_stats
from ir_ref.facts import char_freq_fact, indicator_fact, dt_match_facts
from ir_ref.providers import ReferenceImpactModel, FileDTProvider
from ir_ref.validate import validate
from ir_ref.checker import check
from ir_ref import __version__
REPO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(REPO, 'cwru')
if not glob.glob(os.path.join(ROOT, 'Normal', '*.mat')) or not glob.glob(os.path.join(ROOT, '12k_Drive_End_Bearing_Fault_Data', '**', '*.mat'), recursive=True):
    raise SystemExit(f"CWRU data not found in: {ROOT}\nExpected sub-folders 'Normal' and '12k_Drive_End_Bearing_Fault_Data' containing .mat files.\nRun examples/download_cwru.py first, or pass the data folder as an argument.")
FS = 12000
GEOM = {'n': 9, 'd': 0.3126, 'D': 1.537, 'alpha_deg': 0.0}
BAND = (2000, 5000)
NOMINAL_RPM = {0: 1797, 1: 1772, 2: 1750, 3: 1730}
CFG = dict(s_min=0.2, rho_min=3.0, delta=0.1, snr_min=3.0, lam=3.0)
PROVIDER = ReferenceImpactModel()

def load(path):
    m = sio.loadmat(path)
    de = [k for k in m if k.endswith('_DE_time')]
    num = re.findall('(\\d+)', os.path.basename(path))[0]
    key = [k for k in de if num.zfill(3) in k] or de
    x = m[key[0]].ravel().astype(float)
    rpmk = [k for k in m if k.endswith('RPM')]
    return (x, float(m[rpmk[0]].ravel()[0]) if rpmk else None)
base = {}
for p in sorted(glob.glob(os.path.join(ROOT, 'Normal', '*.mat'))):
    load_hp = int(re.findall('_(\\d)\\.mat', p)[0])
    x, rpm = load(p)
    x = resample_poly(x, 1, 4)
    half = len(x) // 2
    xb, xt = (x[:half], x[half:])
    f, Eb = envelope_spectrum(xb, FS, BAND)
    mu, sd, n = segment_stats(xb, FS, 1.0, kurtosis)
    base[load_hp] = dict(f=f, E=Eb, mu=mu, sd=sd, n=n, rpm=rpm or NOMINAL_RPM[load_hp], test=xt, N=len(xb))

def make_record(x, rpm, load_hp, src, use_amplitude=True):
    b = base[load_hp]
    xr = x[:b['N']] if len(x) >= b['N'] else x
    f, E = envelope_spectrum(xr, FS, BAND)
    Eb = np.interp(f, b['f'], b['E'])
    df = f[1] - f[0]
    fr = rpm / 60
    facts = [char_freq_fact(f'F{i + 1}', f, E, fr, GEOM, flt, 1, df, snr_min=CFG['snr_min']) for i, flt in enumerate(['outer_race', 'inner_race', 'rolling_element'])]
    k = kurtosis(xr)
    _, ku, _ = segment_stats(xr, FS, 1.0, kurtosis)
    facts.append(indicator_fact('F4', 'kurtosis', k, ku, b['mu'], b['sd'], b['n'], CFG['lam']))
    m, ranking = dt_match_facts(5, f, E, Eb, fr, GEOM, (5, 500), s_min=CFG['s_min'], rho_min=CFG['rho_min'], delta=CFG['delta'], delta_f=df, use_amplitude=use_amplitude, provider=PROVIDER)
    facts += m
    held = [o for o in m if o['holds']]
    if not held:
        state, basis = ('no fault evidence', ['F4'] + [o['id'] for o in m])
    elif ranking['ambiguous']:
        state, basis = ('ambiguous: ' + '/'.join(ranking['candidates'][:2]), [o['id'] for o in held])
    else:
        best = max(held, key=lambda o: o['inputs']['similarity'])
        cf_id = {'outer_race': 'F1', 'inner_race': 'F2', 'rolling_element': 'F3'}[best['fault']]
        state, basis = (f'degraded (hypothesis: {best['fault']})', [best['id'], cf_id, 'F4'])
    return {'schema_version': '0.1', 'asset': 'CWRU/drive-end bearing 6205', 'time': '2026-01-01T00:00:00Z', 'regime': {'speed_rpm': rpm, 'load_hp': load_hp}, 'validity': {'speed_rpm': [1700, 1800], 'load_hp': [0, 3]}, 'source': {'dataset': 'CWRU', 'file': src, 'channel': 'DE', 'fs_hz': FS, 'time_window_s': [0, len(xr) / FS]}, 'processing': {'envelope_band_hz': list(BAND), 'delta_f_hz': df}, 'facts': facts, 'state': state, 'basis': basis, 'ranking': ranking, 'policy': {'urgent_if_any': [], 'final_decision': 'engineer'}, 'versions': {'estimator': f'ir_ref {__version__}', **PROVIDER.metadata()}, 'allowed': ['explain', 'prioritize'], 'forbidden': ['control action']}
cases = [('healthy', None, b['test'], b['rpm'], L, f'Normal/{L}hp (2nd half)') for L, b in base.items()]
for p in sorted(glob.glob(os.path.join(ROOT, '12k_Drive_End_Bearing_Fault_Data', '**', '*.mat'), recursive=True)):
    parts = os.path.relpath(p, os.path.join(ROOT, '12k_Drive_End_Bearing_Fault_Data')).replace('\\', '/').split('/')
    cls = {'OR': 'outer_race', 'IR': 'inner_race', 'B': 'rolling_element'}[parts[0]]
    size = re.findall('[/\\\\](0\\d\\d)[/\\\\]', p)[0]
    L = int(re.findall('_(\\d)\\.mat', p)[0])
    x, rpm = load(p)
    cases.append((cls, size, x, rpm or NOMINAL_RPM[L], L, os.path.relpath(p, ROOT)))
results = {}
for amp in (False, True):
    recs = [(c[0], c[1], make_record(c[2], c[3], c[4], c[5], use_amplitude=amp)) for c in cases]
    results['shape+amplitude' if amp else 'shape only'] = recs

def summarize(recs):
    out = {}
    for cls in ['healthy', 'outer_race', 'inner_race', 'rolling_element']:
        R = [r for c, s, r in recs if c == cls]
        hyp = [re.findall('hypothesis: (\\w+)', r['state']) for r in R]
        correct = sum((1 for h in hyp if h and h[0] == cls))
        wrong = sum((1 for h in hyp if h and h[0] != cls))
        amb = sum((1 for r in R if r['state'].startswith('ambiguous')))
        none = sum((1 for r in R if r['state'] == 'no fault evidence'))
        out[cls] = dict(n=len(R), correct=correct, wrong=wrong, ambiguous=amb, no_evidence=none)
    return out
summary = {k: summarize(v) for k, v in results.items()}
recs = results['shape+amplitude']
cf = {'outer_race': 'F1', 'inner_race': 'F2', 'rolling_element': 'F3'}
cf_stats = {}
for cls in ['healthy', 'outer_race', 'inner_race', 'rolling_element']:
    R = [r for c, s, r in recs if c == cls]
    row = {}
    for flt, fid in cf.items():
        row[fid + '(' + flt + ')'] = sum((next((f for f in r['facts'] if f['id'] == fid))['holds'] for r in R))
    row['F4 kurtosis'] = sum((next((f for f in r['facts'] if f['id'] == 'F4'))['holds'] for r in R))
    cf_stats[cls] = {'n': len(R), **row}
val = [validate(r) for _, _, r in recs]
n_valid = sum((v['valid'] for v in val))
n_flag = sum((bool(v['flags']) for v in val))
ood = json.loads(json.dumps(recs[5][2]))
ood['regime']['speed_rpm'] = 2500
ood_flag = validate(ood)['flags']
tamper = json.loads(json.dumps(recs[5][2]))
tamper['facts'][0]['holds'] = not tamper['facts'][0]['holds']
tamper_err = validate(tamper)['errors']
random.seed(0)

def explain(r):
    F = {f['id']: f for f in r['facts']}
    s = []
    for fid in ('F1', 'F2', 'F3'):
        f = F[fid]
        key = f['stmt'].split('at ')[-1]
        s.append(f'The envelope spectrum shows a peak at {f['value']:.1f} Hz near {key} [{fid}].' if f['holds'] else f'There is no envelope peak at {key} [{fid}].')
    k = F['F4']
    s.append(f'The kurtosis is {k['value']:.2f}, {('above' if k['holds'] else 'within')} its baseline of {k['ref']:.2f} [F4].' if k['holds'] else f'The kurtosis of {k['value']:.2f} is within baseline [F4].')
    held = [F[i] for i in ('F5', 'F6', 'F7') if F[i]['holds']]
    for d in held:
        s.append(f'The signature is consistent with the {d['fault'].replace('_', ' ')} hypothesis of the digital twin (similarity {d['value']:.2f}) [{d['id']}].')
    return (' '.join(s), held)

def inject(text, r, kind):
    F = {f['id']: f for f in r['facts']}
    if kind == 'unknown_id':
        return text.replace('[F4]', '[F9]', 1)
    if kind == 'value_mismatch':
        m = re.search('(\\d+\\.\\d+)', text)
        v = float(m.group(1))
        return text.replace(m.group(1), f'{v * 1.15:.2f}', 1)
    if kind == 'uncited_conclusion':
        return text + ' The bearing has an inner race defect.'
    if kind == 'hypothesis_as_certainty':
        d = next((F[i] for i in ('F5', 'F6', 'F7') if F[i]['holds']), None)
        if d is None:
            return None
        return text + f' The bearing definitely has a {d['fault'].replace('_', ' ')} defect [{d['id']}].'
    if kind == 'polarity_contradiction':
        f = next((F[i] for i in ('F1', 'F2', 'F3') if not F[i]['holds']), None)
        if f is None:
            return None
        return text + f' The envelope spectrum shows a clear peak near {f['stmt'].split('at ')[-1]} [{f['id']}].'
    if kind == 'fault_inconsistent_with_evidence':
        f = next((F[i] for i in ('F1', 'F2', 'F3') if F[i]['holds']), None)
        if f is None:
            return None
        other = {'outer_race': 'inner race', 'inner_race': 'outer race', 'rolling_element': 'outer race'}[f['fault']]
        return text + f' This peak is caused by an {other} defect [{f['id']}].'
KINDS = ['unknown_id', 'value_mismatch', 'uncited_conclusion', 'hypothesis_as_certainty', 'polarity_contradiction', 'fault_inconsistent_with_evidence']
chk = {'clean_false_alarm': [0, 0], **{k: [0, 0] for k in KINDS}}
for _, _, r in recs:
    txt, _ = explain(r)
    rep = check(txt, r)
    chk['clean_false_alarm'][0] += any((x['issues'] for x in rep))
    chk['clean_false_alarm'][1] += 1
    for k in KINDS:
        t2 = inject(txt, r, k)
        if t2 is None:
            continue
        rep = check(t2, r)
        chk[k][0] += any((k in x['issues'] for x in rep))
        chk[k][1] += 1
out = {'config': CFG, 'n_records': len(recs), 'diagnosis': summary, 'facts': cf_stats, 'validation': {'valid': n_valid, 'domain_flags_on_valid': n_flag, 'ood_test_flags': ood_flag, 'tampered_record_errors': tamper_err}, 'checker': {k: f'{v[0]}/{v[1]}' for k, v in chk.items()}}
OUT = os.path.join(REPO, 'out')
os.makedirs(OUT, exist_ok=True)
json.dump(out, open(os.path.join(OUT, 'poc_summary.json'), 'w'), indent=1)
json.dump(recs[5][2], open(os.path.join(OUT, 'example_record.json'), 'w'), indent=1, default=float)
print('Results written to', OUT)
print(json.dumps(out, indent=1))
